package dk.dtu.compute.se.pisd.roborally.controller;

import dk.dtu.compute.se.pisd.roborally.model.Command;
import dk.dtu.compute.se.pisd.roborally.model.CommandCard;
import dk.dtu.compute.se.pisd.roborally.model.Heading;
import dk.dtu.compute.se.pisd.roborally.model.Space;

public class Laser extends FieldAction {

    private Laser.laserType laserType;

    public void setAmountOfLaser(int amountOfLaser) {
        this.amountOfLaser = amountOfLaser;
    }

    private int amountOfLaser;
    private Heading headin;

    public enum laserType {
        START,
        MIDDLE,
        END
    }

    public Heading getHeadin() {
        return headin;
    }

    public Laser.laserType getLaserType() {
        return laserType;
    }

    public int getAmountOfLaser() {
        return amountOfLaser;
    }

    /**
     * makes the player draw damage cards, decided by the amount of lasers
     *
     * @param gameController the gameController of the respective game
     * @param space the space this action should be executed for
     *
     * @author Louis Monty-Krohn
     */
    @Override
    public boolean doAction(GameController gameController, Space space) {
        for(int i = 0; i< amountOfLaser; i++){
        }
        return false;
    }
}
