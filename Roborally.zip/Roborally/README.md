# PISD  02362 - Roborally - Gruppe7



## Features for our current version of RoboRally:
-Walls
-Robots are pushable
-Conveyor belts (single moving 1 space and double moving 2 spaces)



**pits, checkpoints and rebooting is implemented but is not working**





### HOW TO RUN THE GAME
Open the project in IntelliJ

Go to -> roborally/src/main/java/dk.dtu.compute.se.pisd/roborally/startRoborally

press shift+F10 (works on windows)
Or press the green play button in the top right corner
