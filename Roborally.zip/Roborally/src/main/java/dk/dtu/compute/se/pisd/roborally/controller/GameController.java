/*
 *  This file is part of the initial project provided for the
 *  course "Project in Software Development (02362)" held at
 *  DTU Compute at the Technical University of Denmark.
 *
 *  Copyright (C) 2019, 2020: Ekkart Kindler, ekki@dtu.dk
 *
 *  This software is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; version 2 of the License.
 *
 *  This project is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this project; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package dk.dtu.compute.se.pisd.roborally.controller;

import dk.dtu.compute.se.pisd.roborally.model.*;
import org.jetbrains.annotations.NotNull;

public class GameController {

    protected boolean winnerFound = false;
    protected AppController appController;
    final public Board board;

    public GameController(@NotNull Board board) {
        this.board = board;
        this.appController = appController;
    }

    public void startProgrammingPhase() {
        board.setPhase(Phase.PROGRAMMING);
        board.setCurrentPlayer(board.getPlayer(0));
        board.setStep(0);

        if (!board.getIsFirstTurnOfLoadedGame()) {
            for (int i = 0; i < board.getNumberOfPlayers(); i++) {
                this.DealNewCardsToPlayer(board.getPlayer(i));
            }
        } else {
            board.setIsFirstTurnOfLoadedGame(false);
        }
    }


    private CommandCard generateRandomCommandCard() {
        Command[] commands = Command.values();
        int random = (int) (Math.random() * commands.length);
        return new CommandCard(commands[random]);
    }

    public void DealNewCardsToPlayer(Player player) {
        if (player != null) {
            for (int j = 0; j < Player.NO_REGISTERS; j++) {
                CommandCardField field = player.getProgramField(j);
                field.setCard(null);
                field.setVisible(true);
            }
            for (int j = 0; j < Player.NO_CARDS; j++) {
                CommandCardField field = player.getCardField(j);
                field.setCard(generateRandomCommandCard());
                field.setVisible(true);
            }
        }
    }

    /**
     * Finish programming phase and transition to activation phase.
     */
    public void finishProgrammingPhase() {
        makeProgramFieldsInvisible();
        makeProgramFieldsVisible(0);
        board.setPhase(Phase.ACTIVATION);
    }

    private void makeProgramFieldsInvisible() {
        for (int i = 0; i < board.getNumberOfPlayers(); i++) {
            Player player = board.getPlayer(i);
            for (int j = 0; j < Player.NO_REGISTERS; j++) {
                CommandCardField field = player.getProgramField(j);
                field.setVisible(false);
            }
        }
    }

    private void makeProgramFieldsVisible(int register) {
        if (register >= 0 && register < Player.NO_REGISTERS) {
            for (int i = 0; i < board.getNumberOfPlayers(); i++) {
                Player player = board.getPlayer(i);
                CommandCardField field = player.getProgramField(register);
                field.setVisible(true);
            }
        }
    }

    public void executePrograms() {
        board.setStepMode(false);
        continuePrograms();
    }

    /**
     * Starts round wiht stepmode set to true
     */
    public void executeStep() {
        board.setStepMode(true);
        continuePrograms();
    }

    /**
     * Continues the execution of the programs of all players.
     */
    private void continuePrograms() {
        do {
            executeNextStep();
        } while (board.getPhase() == Phase.ACTIVATION && !board.isStepMode());
    }


    /**
     * Executes the next step of the programs of all players.
     */
    protected void executeNextStep() {
        Player currentPlayer = board.getCurrentPlayer();
        if (board.getPhase() == Phase.ACTIVATION && currentPlayer != null) {
            int step = board.getStep();
            if (step >= 0 && step < Player.NO_REGISTERS) {
                CommandCard card = currentPlayer.getProgramField(step).getCard();
                if (card != null && !card.command.isInteractive()) {
                    Command command = card.command;
                    executeCommand(currentPlayer, command);
                    if (isPreviousCardInteractive()) {
                        return;
                    }
                } else if (card != null) {
                    board.setPhase(Phase.PLAYER_INTERACTION);
                    return;
                }
                setNextPlayerToCurrent(currentPlayer, step);
            } else {
                // this should not happen
                assert false;
            }
        } else {
            // this should not happen
            assert false;
        }
    }

    /**
     * executes the given command for the current player.
     *
     * @param player
     * @param command
     */
    private void executeCommand(@NotNull Player player, Command command) {
        if (player.board == board && command != null) {

            switch (command) {
                case FORWARD_1:
                    this.movePlayer(player, 1, false);
                    break;
                case RIGHT:
                    this.turnRight(player);
                    break;
                case LEFT:
                    this.turnLeft(player);
                    break;
                case FORWARD_2:
                    this.movePlayer(player, 2, false);
                    break;
                case FORWARD_3:
                    this.movePlayer(player, 3, false);
                    break;
                case U_TURN:
                    this.makeUTurn(player);
                    break;
                case BACKWARD:
                    this.movePlayer(player, 1, true);
                    break;
                case AGAIN:
                    this.playPrevCardAgain(player, 0);
                    break;
                default:
                    // DO NOTHING
            }
        }
    }


    // TODO: V2

    /**
     * Moves a player on the board. The player can move forward or backward based on the MoveBackwards parameter.
     * The player will continue to move until they have moved the specified number of spaces, or until they fall in a pit or off the board.
     * If the player face a wall, the movement will stop.
     * If the target space is occupied by another player, the current player will attempt to push the other player.
     *
     * @param player        The player to be moved.
     * @param SpacesToMove  The number of spaces the player should move.
     * @param MoveBackwards If true, the player moves in the opposite direction of their current heading.
     */
    public void movePlayer(@NotNull Player player, int SpacesToMove, boolean MoveBackwards) {
        boolean again = false;
        do {
            Space space = player.getSpace();
            player.setPrevSpace(player.getSpace());
            if (player != null && player.board == board && space != null) {
                Heading heading = player.getHeading();
                if (MoveBackwards) {
                    heading = heading.next();
                    heading = heading.next();
                }
                Space target = board.getNeighbour(space, heading);
                if (willHitWall(space, target, heading)) {
                    return;
                }
                if (target != null && target.getPlayer() == null) {
                    target.setPlayer(player);
                } else {
                    if (pushRobot(target.getPlayer(), heading)) {
                        target.setPlayer(player);
                    }
                }
                checkPit(target);
            }
            SpacesToMove--;
        } while (SpacesToMove > 0 && !again);
    }

    /**
     * Attempts to push a player to a neighbouring space in a specified direction.
     * If the target space is occupied by another player, the method will recursively attempt to push that player as well.
     * The method also checks for collisions with walls and pits.
     *
     * @param player  The player to be pushed.
     * @param heading The direction in which the player should be pushed.
     * @return Returns true if the player was successfully pushed and false if the push was obstructed by a wall.
     */
    public boolean pushRobot(@NotNull Player player, Heading heading) {
        Space space = player.getSpace();
        if (player.board == board && space != null) {
            Space target = board.getNeighbour(space, heading);
            if (willHitWall(space, target, heading)) {
                return false;
            }
            if (target != null && target.getPlayer() == null) {
                player.setPrevSpace(player.getSpace());
                target.setPlayer(player);
                checkPit(target);
                return true;
            } else {
                if (target != null && pushRobot(target.getPlayer(), heading)) {
                    player.setPrevSpace(player.getSpace());
                    target.setPlayer(player);
                    checkPit(target);
                    return true;
                }
            }
        }
        return false;
    }

    public void turnRight(@NotNull Player player) {
        if (player != null && player.board == board) {
            player.setHeading(player.getHeading().next());
        }
    }

    public void turnLeft(@NotNull Player player) {
        if (player != null && player.board == board) {
            player.setHeading(player.getHeading().prev());
        }
    }

    /**
     * Turns the player around
     *
     * @param player subject to be turned
     */
    public void makeUTurn(@NotNull Player player) {
        if (player.board == board) {
            player.setHeading(player.getHeading().prev());
            player.setHeading(player.getHeading().prev());
        }
    }

    public boolean moveCards(@NotNull CommandCardField source, @NotNull CommandCardField target) {
        CommandCard sourceCard = source.getCard();
        CommandCard targetCard = target.getCard();
        if (sourceCard != null && targetCard == null) {
            target.setCard(sourceCard);
            source.setCard(null);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Executes the previous command card of the current player if it is not an "AGAIN" card or an interactive card.
     *
     * @param currentPlayer The player whose previous command card should be executed.
     * @param currentStep   The current step in the player's program.
     */

    public void playPrevCardAgain(@NotNull Player currentPlayer, int currentStep) {
        int prevStep = currentStep - 1;
        if (prevStep >= 0) {
            Command command = board.getCurrentPlayer().getProgramField(prevStep).getCard().command;
            if (command == Command.AGAIN && prevStep >= 1) {
                playPrevCardAgain(currentPlayer, prevStep);
            } else if (command != Command.AGAIN && !command.isInteractive()) {
                executeCommand(currentPlayer, command);
            } else {
                board.setPhase(Phase.PLAYER_INTERACTION);
            }
        }
    }

    /**
     * Execute the option chosen, for interactive cards
     *
     * @param player  current player
     * @param command command to be executed
     */
    public void executeOptionAndContinue(@NotNull Player player, Command command) {
        executeCommand(player, command);
        board.setPhase(Phase.ACTIVATION);
        setNextPlayerToCurrent(player, board.getStep());
        if (!board.isStepMode()) {
            continuePrograms();
        }
    }

    /**
     * Sets the next player in the turn order as the current player.
     *
     * @param currentPlayer The player who is currently taking their turn.
     * @param currentStep   The current step in the player's program.
     */
    protected void setNextPlayerToCurrent(Player currentPlayer, int currentStep) {
        int nextPlayerNumber = board.getPlayerNumber(currentPlayer) + 1;
        if (nextPlayerNumber < board.getNumberOfPlayers()) {
            board.setCurrentPlayer(board.getPlayer(nextPlayerNumber));
        } else {
            currentStep++;
            activateFieldActions();
            if (currentStep < Player.NO_REGISTERS) {
                makeProgramFieldsVisible(currentStep);
                board.setStep(currentStep);
                board.setCurrentPlayer(board.getPlayer(0));
            } else {
                startProgrammingPhase();
            }
        }
    }

    /**
     * Activates the actions for each player on the board.
     * This includes executing field actions, handling special cases like conveyor belts,
     * and checking for game conditions like checkpoints, pits, and the winner.
     */
    public void activateFieldActions() {
        for (int i = 0; i < board.getNumberOfPlayers(); i++) {
            board.getPlayer(i).setActivated(false);
        }
        for (int i = 0; i < board.getNumberOfPlayers(); i++) {
            Player currentPlayer = board.getPlayer(i);
            currentPlayer.setPrevSpace(currentPlayer.getSpace());
            Space space = currentPlayer.getSpace();
            if (!currentPlayer.getActivated()) {
                for (FieldAction fieldaction : space.getActions()) {
                    fieldaction.doAction(this, space);
                    if (fieldaction.getClass() == ConveyorBelt.class) {
                        DoubleConveyorBelt(fieldaction, space);
                    }
                }
            }
        }
        for (int i = 0; i < board.getNumberOfPlayers(); i++) {
            Player currentPlayer = board.getPlayer(i);
            currentPlayer.setPrevSpace(currentPlayer.getSpace());
            Space space = currentPlayer.getSpace();
            for (FieldAction fieldaction : space.getActions()) {
                if (fieldaction.getClass() == Checkpoint.class || fieldaction.getClass() == Pit.class) {
                    fieldaction.doAction(this, space);
                }
            }
        }
        for (int i = 0; i < board.getNumberOfPlayers(); i++) {
            checkWinner(board.getPlayer(i));
        }
    }


    private boolean willHitWall(Space spaceFrom, Space spaceTo, Heading direction) {
        return (spaceFrom.getWalls().contains(direction) || spaceTo.getWalls().contains(direction.next().next()));
    }

    /**
     * Checks if the most recent non-"AGAIN" command card in the current player's program is a interactive card.
     *
     * @return true if the most recent non-"AGAIN" command card is interactive, false otherwise.
     */
    private boolean isPreviousCardInteractive() {
        CommandCard card = this.board.getCurrentPlayer().getProgramField(this.board.getStep()).getCard();
        if (card != null) {
            if (card.command == Command.AGAIN) {
                int i = board.getStep();
                while (i >= 0) {
                    if (this.board.getCurrentPlayer().getProgramField(i).getCard().command != Command.AGAIN) {
                        return this.board.getCurrentPlayer().getProgramField(i).getCard().command.isInteractive();
                    }
                    i--;
                }
            }
        }
        return false;
    }

    /**
     * Checks if the given player has won the game by comparing their checkpoint tokens with the total checkpoints.
     * If the player has won, the game is reset.
     *
     * @param player The player to check for winning condition.
     */
    private void checkWinner(Player player) {
        if (player.getCheckpointTokens() == board.checkpoints) {
            winnerFound = true;
        }
        if (winnerFound) {
            appController.resetGame(player);
        }
    }

    /**
     * Checks if the player on the given space has fallen into a pit or off the map.
     * If the player has fallen into a pit or off the map, the player's cards are cleared,
     * the player is moved to a reboot or start space, and the method returns true.
     *
     * @param space The space to check for a pit or off-map condition.
     * @return true if the player has fallen into a pit or off the map, false otherwise.
     */
    private boolean checkPit(Space space) {
        if (space.getPlayer() != null) {
            if (!space.getActions().isEmpty()) {
                if (space.getActions().get(0).getClass() == Pit.class) {
                    space.getActions().get(0).doAction(this, space);
                    return true;
                } else if (OutOfBoard(space.getPlayer().getPrevSpace(), space)) {
                    clearPlayersCards(space.getPlayer());
                    checkForOccupiedSpace(rebootOrStartField(space.getPlayer().getPrevSpace(), space.getPlayer()), Heading.EAST);
                    space.getPlayer().setSpace(rebootOrStartField(space.getPlayer().getPrevSpace(), space.getPlayer()));
                    return true;
                }
            } else if (OutOfBoard(space.getPlayer().getPrevSpace(), space)) {
                clearPlayersCards(space.getPlayer());
                checkForOccupiedSpace(rebootOrStartField(space.getPlayer().getPrevSpace(), space.getPlayer()), Heading.EAST);
                space.getPlayer().setSpace(rebootOrStartField(space.getPlayer().getPrevSpace(), space.getPlayer()));
                return true;
            }
        }
        return false;
    }

    /**
     * Clears the players next programming cards.
     *
     * @param player
     */
    public void clearPlayersCards(Player player) {
        for (int i = board.getStep() + 1; i < 5; i++) {
            player.getProgramField(i).setCard(null);
        }
    }

    /**
     * Checks if the player has fallen out of the board
     *
     * @param prevSpace
     * @param currentSpace
     * @return false if player is still on map
     */
    private boolean OutOfBoard(Space prevSpace, Space currentSpace) {
        if (prevSpace.y == currentSpace.y && (prevSpace.x == currentSpace.x + 1 || prevSpace.x == currentSpace.x - 1)) {
            return false;
        } else if (prevSpace.x == currentSpace.x && (prevSpace.y == currentSpace.y + 1 || prevSpace.y == currentSpace.y - 1)) {
            return false;
        } else if (prevSpace.x == currentSpace.x && prevSpace.y == currentSpace.y) {
            return false;
        } else {
            return true;
        }
    }


    /**
     * Checks if the given space is occupied by a player.
     * If it is, the method checks the next space in the given direction.
     *
     * @param space   The space to check for occupation.
     * @param heading The direction to check for the next space.
     */

    public void checkForOccupiedSpace(Space space, Heading heading) {
        Space nextSpace;
        if (space != null) {
            if (space.getPlayer() != null) {
                if (!space.getActions().isEmpty()) {
                    if (space.getActions().get(0).getClass() == Reboot.class) {
                        Reboot reboot = (Reboot) space.getActions().get(0);
                        nextSpace = board.getNeighbour(space, reboot.getHeading());
                        heading = reboot.getHeading();
                    } else {
                        nextSpace = board.getNeighbour(space, heading);
                    }
                } else {
                    nextSpace = board.getNeighbour(space, heading);
                }
                checkForOccupiedSpace(nextSpace, heading);
                if (space.getPlayer().getStartSpace() != space) {
                    space.getPlayer().setSpace(nextSpace);
                }
            }
        }
    }

    private Space FindRebootSpace() {
        for (int i = 0; i < board.width; i++) {
            for (int j = 0; j < board.height; j++) {
                if (!board.getSpace(i, j).getActions().isEmpty()) {
                    if (board.getSpace(i, j).getActions().get(0).getClass() == Reboot.class) {
                        return board.getSpace(i, j);
                    }
                }
            }
        }
        return null;
    }


    /**
     * Determines the space where the player should be placed after falling into a pit or off the map.
     *
     * @param space  The player's previous space before falling.
     * @param player The player who fell into a pit or off the map.
     * @return The start space of the player if their previous space was in the first three columns, or a reboot space otherwise.
     */
    public Space rebootOrStartField(Space space, Player player) {
        if (space.x < 3) {
            return player.getStartSpace();
        } else {
            return FindRebootSpace();
        }
    }

    /**
     * Checks if space is an DoubleConveyorbelt
     *
     * @param fieldaction
     * @param space
     */
    private void DoubleConveyorBelt(FieldAction fieldaction, Space space) {
        ConveyorBelt conveyorBelt = (ConveyorBelt) fieldaction;
        if (conveyorBelt.getExpress()) {
            Space newSpace = board.getNeighbour(space, conveyorBelt.getHeading());
            if (!newSpace.getActions().isEmpty()) {
                if (newSpace.getActions().get(0).getClass() == ConveyorBelt.class) {
                    ConveyorBelt secondConveyor = (ConveyorBelt) newSpace.getActions().get(0);
                    if (secondConveyor.getExpress()) {
                        conveyorBelt.doAction(this, newSpace);
                    }
                }
            }
        }
    }
}
